﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace Bachelor_GUI
{
    public partial class Form1 : Form
    {
        List<List<Frame>> Data;
        List<Wykres> Charty;
        public Form1()
        {
            Data=new List<List<Frame>>();
            Charty=new List<Wykres>();
            
            InitializeComponent();
            CB_Com.Items.AddRange(SerialPort.GetPortNames());

        }
        void InputData(Frame Input)
        {
            LV_Log.Items.Insert(0, Input.GetLogItem());
            bool find=false;
            int Count = 0;
            foreach(List<Frame> i in Data)
            {
                if(i[0].Adres==Input.Adres)
                {

                    Input.Name = i[0].Name;
                    Input.FactorA = i[0].FactorA;
                    Input.FactorB = i[0].FactorB;
                    i.Insert(0, Input);
                    LV_Data.Items.RemoveAt(Count);
                    LV_Data.Items.Insert(Count, Input.GetDataItem());
                    
                    find = true;
                    break;
                }
                Count++;//Ale się naszukałem....
            }
            if(find==false)
            {
                Data.Add(new List<Frame>());
                Data[Data.Count-1].Insert(0, Input);
                LV_Data.Items.Add(Input.GetDataItem());
            }
        }

        private void BTTN_Load_Click(object sender, EventArgs e)
        {
            oFD_Load.ShowDialog();
        }

        private void oFD_Load_FileOk(object sender, CancelEventArgs e)
        {
            
            string[] lines = System.IO.File.ReadAllLines(oFD_Load.FileName.ToString());
            foreach(string line in lines)
            {
                Frame Temp_Frame = new Frame(line);
                this.InputData(Temp_Frame);
            }
        }

        private void TB_Name_TextChanged(object sender, EventArgs e)
        {
            if (LV_Data.SelectedIndices.Count == 1)
            {
                int Count = LV_Data.SelectedIndices[0];
                foreach (Frame Data_Frame in Data[Count])
                {
                    Data_Frame.Name = TB_Name.Text;
                }
            }
        }

        private void LV_Data_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LV_Data.SelectedIndices.Count == 1)
            {
                int Count = LV_Data.SelectedIndices[0];
                TB_Adres.Text = Data[Count][0].Adres;
                TB_Name.Text = Data[Count][0].Name;
                TB_Canal_1.Text = Data[Count][0].dCanal[0].ToString();
                TB_Canal_2.Text = Data[Count][0].dCanal[1].ToString();
                TB_Value_1.Text = Data[Count][0].Value[0].ToString();
                TB_Value_2.Text = Data[Count][0].Value[1].ToString();
                TB_Comment.Text = Data[Count][0].Comment;
                TB_FactorA1.Text = Data[Count][0].FactorA[0].ToString();
                TB_FactorA2.Text = Data[Count][0].FactorA[1].ToString();
                TB_FactorB1.Text = Data[Count][0].FactorB[0].ToString();
                TB_FactorB2.Text = Data[Count][0].FactorB[1].ToString();
            }
        }

        private void TB_FactorA1_TextChanged(object sender, EventArgs e)
        {
            if (LV_Data.SelectedIndices.Count == 1)
            {
                int Count = LV_Data.SelectedIndices[0];
                Double FactorA;
                try
                {
                    FactorA = double.Parse(TB_FactorA1.Text);
                }
                catch(FormatException)
                {
                    FactorA = 1;
                }
                foreach(Frame Data_Frame in Data[Count])
                {
                    Data_Frame.FactorA[0] = FactorA;
                    Data_Frame.ConvertValue();
                    Data_Frame.ReMake();
                }
                //Data[Count][0].FactorA[0] = Convert.ToDouble(TB_FactorA1.Text);

                //LV_Data.Items[Count].SubItems[0].Text = Data[Count][0].Adres;
                //LV_Data.Items[Count].SubItems[5].Text = Data[Count][0].Value[0].ToString();
                //LV_Data.Items[Count].SubItems[8].Text = TB_FactorA1.Text;
                //LV_Data.Items.Insert(Count, Data[Count][0].GetDataItem());
                //LV_Data.Items.RemoveAt(Count+1);


            }
        }

        private void TB_FactorB1_TextChanged(object sender, EventArgs e)
        {
            if (LV_Data.SelectedIndices.Count == 1)
            {
                int Count = LV_Data.SelectedIndices[0];
                Double FactorB;
                try
                {
                    FactorB = double.Parse(TB_FactorB1.Text);
                }
                catch (FormatException)
                {
                    FactorB = 0;
                }
                foreach (Frame Data_Frame in Data[Count])
                {
                    Data_Frame.FactorB[0] = FactorB;
                    Data_Frame.ConvertValue();
                    Data_Frame.ReMake();
                }
                //Data[Count][0].FactorA[0] = Convert.ToDouble(TB_FactorA1.Text);

                //LV_Data.Items[Count].SubItems[5].Text = Data[Count][0].Value[0].ToString();
                //LV_Data.Items[Count].SubItems[10].Text = TB_FactorB1.Text;
                //LV_Data.Items.Insert(Count, Data[Count][0].GetDataItem());
                //LV_Data.Items.RemoveAt(Count+1);


            }
        }

        private void TB_FactorA2_TextChanged(object sender, EventArgs e)
        {
            if (LV_Data.SelectedIndices.Count == 1)
            {
                int Count = LV_Data.SelectedIndices[0];
                Double FactorA;
                try
                {
                    FactorA = double.Parse(TB_FactorA2.Text);
                }
                catch (FormatException)
                {
                    FactorA = 0;
                }
                foreach (Frame Data_Frame in Data[Count])
                {
                    Data_Frame.FactorA[1] = FactorA;
                    Data_Frame.ConvertValue();
                    Data_Frame.ReMake();
                }
                //Data[Count][0].FactorA[0] = Convert.ToDouble(TB_FactorA1.Text);

                //LV_Data.Items[Count].SubItems[5].Text = Data[Count][0].Value[0].ToString();
                //LV_Data.Items[Count].SubItems[9].Text = TB_FactorA2.Text;
                //LV_Data.Items.Insert(Count, Data[Count][0].GetDataItem());
                //LV_Data.Items.RemoveAt(Count+1);


            }
        }

        private void TB_FactorB2_TextChanged(object sender, EventArgs e)
        {
            if (LV_Data.SelectedIndices.Count == 1)
            {
                int Count = LV_Data.SelectedIndices[0];
                Double FactorB;
                try
                {
                    FactorB = double.Parse(TB_FactorB2.Text);
                }
                catch (FormatException)
                {
                    FactorB = 0;
                }
                foreach (Frame Data_Frame in Data[Count])
                {
                    Data_Frame.FactorB[1] = FactorB;
                    Data_Frame.ConvertValue();
                    Data_Frame.ReMake();
                }
                //Data[Count][0].FactorA[0] = Convert.ToDouble(TB_FactorA1.Text);

                //LV_Data.Items[Count].SubItems[5].Text = Data[Count][0].Value[0].ToString();
                //LV_Data.Items[Count].SubItems[11].Text = TB_FactorB2.Text;
                //LV_Data.Items.Insert(Count, Data[Count][0].GetDataItem());
                //LV_Data.Items.RemoveAt(Count+1);


            }
        }

        private void TB_Comment_TextChanged(object sender, EventArgs e)
        {
            if (LV_Data.SelectedIndices.Count == 1)
            {
                int Count = LV_Data.SelectedIndices[0];
                foreach (Frame Data_Frame in Data[Count])
                {
                    Data_Frame.Comment = TB_Comment.Text;
                }
            }
        }

        private void LV_Data_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Charty.Add(new Wykres(Data, LV_Data.SelectedIndices));
            Charty[Charty.Count - 1].Show();
        }

        private void LV_Data_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Charty.Add(new Wykres(Data, LV_Data.SelectedIndices));
                Charty[Charty.Count - 1].Show();
            }
        }

    }
}
