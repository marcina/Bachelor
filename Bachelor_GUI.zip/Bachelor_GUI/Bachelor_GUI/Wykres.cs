﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bachelor_GUI
{
    public partial class Wykres : Form
    {
        public Wykres()
        {
            InitializeComponent();
        }
        public Wykres(List<List<Frame>> Data,ListView.SelectedIndexCollection Count)
        {
            InitializeComponent();
            //if(string.IsNullOrEmpty(Data[Count][0].Name))
            //{
            //    Chart.Series.Add(Data[Count][0].Adres);
            //    Chart.Series[Data[Count][0].Adres].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            //}
            //else
            //{
            //    Chart.Series.Add(Data[Count][0].Name + "(" + Data[Count][0].Adres + ")");
            //    Chart.Series[Data[Count][0].Name + "(" + Data[Count][0].Adres + ")"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            //}
            
            int i = 0;
            foreach(List<Frame> List_Frame in Data)
            {
                if (string.IsNullOrEmpty(List_Frame[0].Name))
                {
                    Chart.Series.Add(List_Frame[0].Adres);
                    Chart.Series[List_Frame[0].Adres].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                    Chart.Series[List_Frame[0].Adres].Enabled = false;

                    System.Windows.Forms.ToolStripMenuItem temp = new System.Windows.Forms.ToolStripMenuItem();
                    temp.Text = List_Frame[0].Adres;
                    temp.Checked = false;
                    temp.Click += new System.EventHandler(this.Char_Click);
                    // this.button1.Click += new System.EventHandler(this.button1_Click);
                    ChartStrip.DropDownItems.Add(temp);

                    foreach (int j in Count)
                    {
                        if (i == j)
                        {
                            Chart.Series[List_Frame[0].Adres].Enabled = true;
                            temp.Checked = true;
                            this.Text += List_Frame[0].Adres+" ";
                        }
                    }

                }
                else
                {
                    Chart.Series.Add(List_Frame[0].Name + "(" + List_Frame[0].Adres + ")");
                    Chart.Series[List_Frame[0].Name + "(" + List_Frame[0].Adres + ")"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                    Chart.Series[List_Frame[0].Name + "(" + List_Frame[0].Adres + ")"].Enabled = false;
              
                    System.Windows.Forms.ToolStripMenuItem temp = new System.Windows.Forms.ToolStripMenuItem();
                    temp.Text = List_Frame[0].Name + "(" + List_Frame[0].Adres + ")";
                    temp.Checked = false;
                    temp.Click += new System.EventHandler(this.Char_Click);
                    ChartStrip.DropDownItems.Add(temp);

                    foreach (int j in Count)
                    {
                        if (i == j)
                        {
                            Chart.Series[List_Frame[0].Name + "(" + List_Frame[0].Adres + ")"].Enabled = true;
                            temp.Checked = true;
                            this.Text += List_Frame[0].Name + "(" + List_Frame[0].Adres + ")"+" ";
                        }
                    }
                }

                foreach(Frame Data_Frame in List_Frame)
                {
                    if (string.IsNullOrEmpty(List_Frame[0].Name))
                    {
                        Chart.Series[List_Frame[0].Adres].Points.AddY(Data_Frame.Value[0]);
                    }
                    else
                    {
                        Chart.Series[List_Frame[0].Name + "(" + List_Frame[0].Adres + ")"].Points.AddY(Data_Frame.Value[0]);
                    }
                }
                i++;
            }
            //foreach(Frame Data_Frame in Data[Count])
            //{
            //    if (string.IsNullOrEmpty(Data[Count][0].Name))
            //    {
            //        Chart.Series[Data[Count][0].Adres].Points.AddY(Data_Frame.Value[0]);
            //    }
            //    else
            //    {
            //        Chart.Series[Data[Count][0].Name + "(" + Data[Count][0].Adres + ")"].Points.AddY(Data_Frame.Value[0]);
            //    }
            //}
            
        }
        public void ChangeName(string Old,string New)
        {

        }
        private void Char_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.ToolStripMenuItem temp = (System.Windows.Forms.ToolStripMenuItem)sender;
            if(Chart.Series[temp.Text].Enabled)
            {
                Chart.Series[temp.Text].Enabled = false;
                temp.Checked = false;
            }
            else
            {
                Chart.Series[temp.Text].Enabled = true;
                temp.Checked=true;
            }
        }

    }
}
