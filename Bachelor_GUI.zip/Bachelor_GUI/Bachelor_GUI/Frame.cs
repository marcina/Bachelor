﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bachelor_GUI
{
    public class Frame
    {
        string Orgin;
        string Time;
        public string Adres;
        private string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
                Data_Item.SubItems[2].Text = name;
                Log_Item.SubItems[2].Text = name;
            }
        }
        string DLC;
        int iDLC;
        string[] Canal;
        public double[] dCanal;
        public double[] Value;
        //private double[] factora;
        public double[] FactorA;

        public double[] FactorB;
        private string comment;
        public string Comment
        {
            get
            {
                return comment;
            }
            set
            {
                comment = value;
                Log_Item.SubItems[7].Text = comment;
                Data_Item.SubItems[7].Text = comment;

            }
        }
        ListViewItem Data_Item;
        ListViewItem Log_Item;

        public Frame()
        {
            Data_Item = new ListViewItem();
            Log_Item = new ListViewItem();
        }
        public Frame(string Frame)
        {
            name = "";
            this.Orgin = Frame;
            Adres = Orgin.Substring(0, 8);
            DLC = Orgin.Substring(8, 2);
            iDLC = Convert.ToInt16(DLC) / 2;
            if (iDLC > 2)
            {
                Canal = new string[iDLC];
                Value = new double[iDLC];
                dCanal = new double[iDLC];
                FactorA = new double[iDLC];
                FactorB = new double[iDLC];
            }
            else
            {
                Canal = new string[2];
                Value = new double[2];
                dCanal = new double[2];
                FactorA = new double[2];
                FactorB = new double[2];
            }
            for (int i = 0; iDLC != i;i++ )
            {
                Canal[i] = Orgin.Substring(10+i*4, 4);
                
                dCanal[i] = int.Parse(Canal[i], System.Globalization.NumberStyles.HexNumber);
                Value[i] = dCanal[i];
                FactorA[i] = 1;
                FactorB[i]=0;
            }

                this.make();
        }
        public void make()
        {
            Data_Item = new ListViewItem();
            Log_Item = new ListViewItem();
            Data_Item.Text = Adres;
            Data_Item.SubItems.Add(DLC);
            Data_Item.SubItems.Add(Name);
            Data_Item.SubItems.Add(Canal[0]);
            Data_Item.SubItems.Add(Canal[1]);
            Data_Item.SubItems.Add(Value[0].ToString());
            Data_Item.SubItems.Add(Value[1].ToString());
            Data_Item.SubItems.Add(comment);
            Data_Item.SubItems.Add(FactorA[0].ToString());
            Data_Item.SubItems.Add(FactorA[1].ToString());
            Data_Item.SubItems.Add(FactorB[0].ToString());
            Data_Item.SubItems.Add(FactorB[1].ToString());

            Log_Item.Text = Time;
            Log_Item.SubItems.Add(Adres);
            Log_Item.SubItems.Add(Name);
            Log_Item.SubItems.Add(Canal[0]);
            Log_Item.SubItems.Add(Canal[1]);
            Log_Item.SubItems.Add(Value[0].ToString());
            Log_Item.SubItems.Add(Value[1].ToString());
            Log_Item.SubItems.Add(comment);
            Log_Item.SubItems.Add(FactorA[0].ToString());
            Log_Item.SubItems.Add(FactorA[1].ToString());
            Log_Item.SubItems.Add(FactorB[0].ToString());
            Log_Item.SubItems.Add(FactorB[1].ToString());

        }
        public void ReMake()
        {
            Data_Item.SubItems[2].Text=Name;
            Data_Item.SubItems[5].Text = (Value[0].ToString());
            Data_Item.SubItems[6].Text = (Value[1].ToString());
            Data_Item.SubItems[7].Text = (comment);
            Data_Item.SubItems[8].Text = (FactorA[0].ToString());
            Data_Item.SubItems[9].Text = (FactorA[1].ToString());
            Data_Item.SubItems[10].Text = (FactorB[0].ToString());
            Data_Item.SubItems[11].Text = (FactorB[1].ToString());

            Log_Item.SubItems[2].Text = (Name);
            Log_Item.SubItems[5].Text = (Value[0].ToString());
            Log_Item.SubItems[6].Text = (Value[1].ToString());
            Log_Item.SubItems[7].Text = (comment);
            Log_Item.SubItems[8].Text = (FactorA[0].ToString());
            Log_Item.SubItems[9].Text = (FactorA[1].ToString());
            Log_Item.SubItems[10].Text = (FactorB[0].ToString());
            Log_Item.SubItems[11].Text = (FactorB[1].ToString());
        }
        public void make(string Frame)
        {
            Data_Item = new ListViewItem();
            Log_Item = new ListViewItem();
            this.Orgin = Frame;

            Data_Item.Text = Adres;
            Data_Item.SubItems.Add(Name);
            Data_Item.SubItems.Add(Canal[0]);
            Data_Item.SubItems.Add(Canal[1]);
            Data_Item.SubItems.Add(Value[0].ToString());
            Data_Item.SubItems.Add(Value[1].ToString());
            Data_Item.SubItems.Add(comment);
            Data_Item.SubItems.Add(FactorA[0].ToString());
            Data_Item.SubItems.Add(FactorA[1].ToString());
            Data_Item.SubItems.Add(FactorB[0].ToString());
            Data_Item.SubItems.Add(FactorB[1].ToString());

            Log_Item.Text = Time;
            Log_Item.SubItems.Add(Adres);
            Log_Item.SubItems.Add(Name);
            Log_Item.SubItems.Add(Canal[0]);
            Log_Item.SubItems.Add(Canal[1]);
            Log_Item.SubItems.Add(Value[0].ToString());
            Log_Item.SubItems.Add(Value[1].ToString());
            Log_Item.SubItems.Add(comment);
            Log_Item.SubItems.Add(FactorA[0].ToString());
            Log_Item.SubItems.Add(FactorA[1].ToString());
            Log_Item.SubItems.Add(FactorB[0].ToString());
            Log_Item.SubItems.Add(FactorB[1].ToString());
        }
        public ListViewItem GetDataItem()
        {
            return Data_Item;
        }
        public ListViewItem GetLogItem()
        {
            return Log_Item;
        }
        public void ConvertValue()
        {
            for (int i = 0; iDLC != i; i++)
            {
                Value[i] = dCanal[i] * FactorA[i] + FactorB[i];
            }
        }
    }
}
