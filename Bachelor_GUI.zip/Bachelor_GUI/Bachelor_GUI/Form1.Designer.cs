﻿namespace Bachelor_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CB_Com = new System.Windows.Forms.ComboBox();
            this.BTN_Connect = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.TB_FactorB2 = new System.Windows.Forms.TextBox();
            this.TB_FactorA2 = new System.Windows.Forms.TextBox();
            this.TB_FactorB1 = new System.Windows.Forms.TextBox();
            this.TB_FactorA1 = new System.Windows.Forms.TextBox();
            this.TB_Comment = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TB_Value_2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TB_Value_1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TB_Canal_2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TB_Canal_1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_Name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TB_Adres = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LV_Data = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.LV_Log = new System.Windows.Forms.ListView();
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.oFD_Load = new System.Windows.Forms.OpenFileDialog();
            this.BTTN_Load = new System.Windows.Forms.Button();
            this.SP_Uart = new System.IO.Ports.SerialPort(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // CB_Com
            // 
            this.CB_Com.FormattingEnabled = true;
            this.CB_Com.Location = new System.Drawing.Point(13, 13);
            this.CB_Com.Name = "CB_Com";
            this.CB_Com.Size = new System.Drawing.Size(121, 21);
            this.CB_Com.TabIndex = 0;
            // 
            // BTN_Connect
            // 
            this.BTN_Connect.Location = new System.Drawing.Point(140, 11);
            this.BTN_Connect.Name = "BTN_Connect";
            this.BTN_Connect.Size = new System.Drawing.Size(75, 23);
            this.BTN_Connect.TabIndex = 1;
            this.BTN_Connect.Text = "Connect";
            this.BTN_Connect.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(1, 40);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(939, 583);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.TB_FactorB2);
            this.tabPage1.Controls.Add(this.TB_FactorA2);
            this.tabPage1.Controls.Add(this.TB_FactorB1);
            this.tabPage1.Controls.Add(this.TB_FactorA1);
            this.tabPage1.Controls.Add(this.TB_Comment);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.TB_Value_2);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.TB_Value_1);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.TB_Canal_2);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.TB_Canal_1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.TB_Name);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.TB_Adres);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.LV_Data);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(931, 557);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Data";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(867, 179);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Factor b";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(806, 179);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "Factor a";
            // 
            // TB_FactorB2
            // 
            this.TB_FactorB2.Location = new System.Drawing.Point(870, 234);
            this.TB_FactorB2.Name = "TB_FactorB2";
            this.TB_FactorB2.Size = new System.Drawing.Size(55, 20);
            this.TB_FactorB2.TabIndex = 18;
            this.TB_FactorB2.Text = "0";
            this.TB_FactorB2.TextChanged += new System.EventHandler(this.TB_FactorB2_TextChanged);
            // 
            // TB_FactorA2
            // 
            this.TB_FactorA2.Location = new System.Drawing.Point(809, 234);
            this.TB_FactorA2.Name = "TB_FactorA2";
            this.TB_FactorA2.Size = new System.Drawing.Size(55, 20);
            this.TB_FactorA2.TabIndex = 17;
            this.TB_FactorA2.Text = "1";
            this.TB_FactorA2.TextChanged += new System.EventHandler(this.TB_FactorA2_TextChanged);
            // 
            // TB_FactorB1
            // 
            this.TB_FactorB1.Location = new System.Drawing.Point(870, 195);
            this.TB_FactorB1.Name = "TB_FactorB1";
            this.TB_FactorB1.Size = new System.Drawing.Size(55, 20);
            this.TB_FactorB1.TabIndex = 16;
            this.TB_FactorB1.Text = "0";
            this.TB_FactorB1.TextChanged += new System.EventHandler(this.TB_FactorB1_TextChanged);
            // 
            // TB_FactorA1
            // 
            this.TB_FactorA1.Location = new System.Drawing.Point(809, 195);
            this.TB_FactorA1.Name = "TB_FactorA1";
            this.TB_FactorA1.Size = new System.Drawing.Size(55, 20);
            this.TB_FactorA1.TabIndex = 15;
            this.TB_FactorA1.Text = "1";
            this.TB_FactorA1.TextChanged += new System.EventHandler(this.TB_FactorA1_TextChanged);
            // 
            // TB_Comment
            // 
            this.TB_Comment.Location = new System.Drawing.Point(703, 273);
            this.TB_Comment.Name = "TB_Comment";
            this.TB_Comment.Size = new System.Drawing.Size(222, 20);
            this.TB_Comment.TabIndex = 14;
            this.TB_Comment.TextChanged += new System.EventHandler(this.TB_Comment_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(700, 257);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Comment";
            // 
            // TB_Value_2
            // 
            this.TB_Value_2.Location = new System.Drawing.Point(703, 234);
            this.TB_Value_2.Name = "TB_Value_2";
            this.TB_Value_2.ReadOnly = true;
            this.TB_Value_2.Size = new System.Drawing.Size(100, 20);
            this.TB_Value_2.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(700, 218);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Value 2";
            // 
            // TB_Value_1
            // 
            this.TB_Value_1.Location = new System.Drawing.Point(703, 195);
            this.TB_Value_1.Name = "TB_Value_1";
            this.TB_Value_1.ReadOnly = true;
            this.TB_Value_1.Size = new System.Drawing.Size(100, 20);
            this.TB_Value_1.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(700, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Value 1";
            // 
            // TB_Canal_2
            // 
            this.TB_Canal_2.Location = new System.Drawing.Point(703, 151);
            this.TB_Canal_2.Name = "TB_Canal_2";
            this.TB_Canal_2.ReadOnly = true;
            this.TB_Canal_2.Size = new System.Drawing.Size(100, 20);
            this.TB_Canal_2.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(700, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Canal 2";
            // 
            // TB_Canal_1
            // 
            this.TB_Canal_1.Location = new System.Drawing.Point(703, 112);
            this.TB_Canal_1.Name = "TB_Canal_1";
            this.TB_Canal_1.ReadOnly = true;
            this.TB_Canal_1.Size = new System.Drawing.Size(100, 20);
            this.TB_Canal_1.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(700, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Canal 1";
            // 
            // TB_Name
            // 
            this.TB_Name.Location = new System.Drawing.Point(703, 67);
            this.TB_Name.Name = "TB_Name";
            this.TB_Name.Size = new System.Drawing.Size(100, 20);
            this.TB_Name.TabIndex = 4;
            this.TB_Name.TextChanged += new System.EventHandler(this.TB_Name_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(703, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Name";
            // 
            // TB_Adres
            // 
            this.TB_Adres.Location = new System.Drawing.Point(703, 24);
            this.TB_Adres.Name = "TB_Adres";
            this.TB_Adres.ReadOnly = true;
            this.TB_Adres.Size = new System.Drawing.Size(100, 20);
            this.TB_Adres.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(700, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Adres";
            // 
            // LV_Data
            // 
            this.LV_Data.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader20,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader18,
            this.columnHeader19});
            this.LV_Data.FullRowSelect = true;
            this.LV_Data.GridLines = true;
            this.LV_Data.HideSelection = false;
            this.LV_Data.Location = new System.Drawing.Point(8, 3);
            this.LV_Data.Name = "LV_Data";
            this.LV_Data.Size = new System.Drawing.Size(685, 543);
            this.LV_Data.TabIndex = 0;
            this.LV_Data.UseCompatibleStateImageBehavior = false;
            this.LV_Data.View = System.Windows.Forms.View.Details;
            this.LV_Data.SelectedIndexChanged += new System.EventHandler(this.LV_Data_SelectedIndexChanged);
            this.LV_Data.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LV_Data_KeyDown);
            this.LV_Data.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.LV_Data_MouseDoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Adres";
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "DLC";
            this.columnHeader20.Width = 39;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Name";
            this.columnHeader2.Width = 55;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Canal 1";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Canal 2";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Value 1";
            this.columnHeader5.Width = 61;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Value 2";
            this.columnHeader6.Width = 69;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Comment";
            this.columnHeader7.Width = 158;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Factor a1";
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Factor a2";
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "factor b1";
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "factor b2";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.LV_Log);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(970, 557);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Log";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // LV_Log
            // 
            this.LV_Log.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader15,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14});
            this.LV_Log.FullRowSelect = true;
            this.LV_Log.GridLines = true;
            this.LV_Log.Location = new System.Drawing.Point(8, 3);
            this.LV_Log.Name = "LV_Log";
            this.LV_Log.Size = new System.Drawing.Size(685, 545);
            this.LV_Log.TabIndex = 1;
            this.LV_Log.UseCompatibleStateImageBehavior = false;
            this.LV_Log.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Time";
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Adres";
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Name";
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Canal 1";
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Canal 2";
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Value 1";
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Value 2";
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Comment";
            // 
            // oFD_Load
            // 
            this.oFD_Load.DefaultExt = "txt";
            this.oFD_Load.FileName = "Data";
            this.oFD_Load.Filter = "Data Files|*.txt";
            this.oFD_Load.FileOk += new System.ComponentModel.CancelEventHandler(this.oFD_Load_FileOk);
            // 
            // BTTN_Load
            // 
            this.BTTN_Load.Location = new System.Drawing.Point(851, 13);
            this.BTTN_Load.Name = "BTTN_Load";
            this.BTTN_Load.Size = new System.Drawing.Size(75, 23);
            this.BTTN_Load.TabIndex = 3;
            this.BTTN_Load.Text = "Load Data";
            this.BTTN_Load.UseVisualStyleBackColor = true;
            this.BTTN_Load.Click += new System.EventHandler(this.BTTN_Load_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(938, 623);
            this.Controls.Add(this.BTTN_Load);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.BTN_Connect);
            this.Controls.Add(this.CB_Com);
            this.Name = "Form1";
            this.Text = "FS_GUI";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox CB_Com;
        private System.Windows.Forms.Button BTN_Connect;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListView LV_Data;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListView LV_Log;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.OpenFileDialog oFD_Load;
        private System.Windows.Forms.Button BTTN_Load;
        private System.Windows.Forms.TextBox TB_Canal_1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_Name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TB_Adres;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_Comment;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TB_Value_2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TB_Value_1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TB_Canal_2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TB_FactorB2;
        private System.Windows.Forms.TextBox TB_FactorA2;
        private System.Windows.Forms.TextBox TB_FactorB1;
        private System.Windows.Forms.TextBox TB_FactorA1;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.IO.Ports.SerialPort SP_Uart;
    }
}

